package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Random;

import starwars.TIEFighter;
import starwars.XWing;

public class Client {
	
	private Socket client;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public Client(String ip, int port) {
		try {
			client = new Socket(ip, port);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void send() {
        try {
        	System.out.println("Client Info: " + client.getLocalSocketAddress());
			oos = new ObjectOutputStream(client.getOutputStream());
			ois = new ObjectInputStream(client.getInputStream());
			
			Random r = new Random();
			boolean alive = true;
			while(alive) {
				if(r.nextBoolean()) {
					TIEFighter tf = new TIEFighter(100);
					oos.writeObject(tf);
				} else {
					XWing xw = new XWing(110);
					oos.writeObject(xw);
				}
				//System.out.println(tf);
				//oos.writeObject(tf);
				Integer hp = (Integer) this.ois.readObject();
				System.out.println("From server: " + hp);
				if(hp <= 0) {
					alive = false;
				}
			}
			
			client.close();	
						
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
