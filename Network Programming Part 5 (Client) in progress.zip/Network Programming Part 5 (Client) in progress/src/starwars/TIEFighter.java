package starwars;

import java.io.Serializable;

public class TIEFighter implements Serializable {
	
	private static final long serialVersionUID = 4971122984541373547L;
	private int materialamount;
	
	public TIEFighter(int material) {
		this.materialamount = material;
	}
	
	public int repair() {
		return this.materialamount;
	}
}
