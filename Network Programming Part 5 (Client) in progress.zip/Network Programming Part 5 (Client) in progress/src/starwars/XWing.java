package starwars;

import java.io.Serializable;

public class XWing implements Serializable {
	
	private static final long serialVersionUID = 1734366716588591443L;
	private int laser;
	
	public XWing(int laser) {
		this.laser = laser;
	}
	
	public int attack() {
		return this.laser;
	}
}
