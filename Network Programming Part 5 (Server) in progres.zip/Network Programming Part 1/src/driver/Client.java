package driver;

import java.io.IOException;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {
		Socket conn = null;
		try {
			conn = new Socket("192.168.0.1", 4242); // connect to the server
			request(conn);							// request service 
			conn.close();							// close the socket
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void request(Socket conn) {
		
	}

}
