package driver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		ServerSocket server = null;
		try {
			server = new ServerSocket(4242);
			while (true) { 						// bad programming but we'll talk about this
				Socket conn = server.accept();	// block waits for a client
				service(conn);					// perform the service for the client
				conn.close();					// close the socket when done
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void service(Socket conn) {
		
	}

}
