package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientHandler extends Thread {
	
	private Socket client;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public ClientHandler(Socket client) {
		this.client = client;	
	}
	
	@Override
	public void run() {
		try {
			ois = new ObjectInputStream(client.getInputStream());
			oos = new ObjectOutputStream(client.getOutputStream());
			while (true) {
				String message = (String) this.ois.readObject();
				System.out.println(message);
				String[] data = message.split(" ");
				String response = ("Server Acknowledges " + data[1]);
				this.oos.writeObject(response);
			}
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
}
