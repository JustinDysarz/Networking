package server;

public class ServerDriver {

	public static void main(String[] args) {
		Server server = new Server(5995);
		server.run();
	}

}
