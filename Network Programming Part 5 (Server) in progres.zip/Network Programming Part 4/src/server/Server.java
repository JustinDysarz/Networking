package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	private ServerSocket server;
	
	public Server(int port) {
		try {
			server = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	public void run() {
		try {
			while (true) {
				System.out.println("Waiting for connection...");
				Socket client = server.accept();
				ClientHandler task = new ClientHandler(client);
				task.start();
			}
			// client.close();	// unreachable because of the infinite loop
			// server.close();	// unreachable because of the infinite loop
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}

}
