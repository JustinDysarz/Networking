package client;

public class ClientDriver {

	public static void main(String[] args) {
		
		for(int i = 0; i < 3; i++) {
			Client client = new Client("localhost", 5995, i);
			//client.run();
			client.start();
		}

	}

}
