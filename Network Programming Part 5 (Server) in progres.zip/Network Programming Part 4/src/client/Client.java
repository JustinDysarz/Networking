package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

// we are threading this client so we can simulate multiple clients
// in one program--imagine having one server and multiple clients connecting
// from the internet
public class Client extends Thread {
	
	private Socket client;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private int clientID;
	private String ip;
	private int port;
	
	
	public Client(String ip, int port, int id) {
		this.clientID = id;
		this.ip	= ip;
		this.port = port;
	}

	public void run() {
        try {
        	this.client = new Socket(ip, port);
			oos = new ObjectOutputStream(client.getOutputStream());
			ois = new ObjectInputStream(client.getInputStream());
			
			while(true) {
				String message = ("Client #" + this.clientID + " message");
				this.oos.writeObject(message);
				String response = (String) this.ois.readObject();
				System.out.println(response);
				Thread.sleep(2000);
			}
			// client.close();	// unreachable with the infinite loop 
						
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
