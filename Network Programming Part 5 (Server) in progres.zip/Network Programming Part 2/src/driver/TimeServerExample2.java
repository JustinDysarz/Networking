package driver;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class TimeServerExample2 {

	public static void main(String[] args) {
		int TIMEOUT = 15000; // 15000 milliseconds
		String timehost = "time.nist.gov";
		int timeport = 13;
		Socket conn = null;
		SocketAddress address = null;
		InputStream istream = null;
		InputStreamReader reader = null;
		
		try {
			// you can create the socket but delay connecting it
			conn = new Socket();
			address = new InetSocketAddress(timehost, timeport);
			conn.setSoTimeout(TIMEOUT); 
			System.out.println("Address  : " + address);
			System.out.println("Info     : " + conn);
			System.out.println("Status   : " + conn.isClosed());
			
			conn.connect(address);
			System.out.println("Info     : " + conn);
			System.out.println("Host IP  : " + conn.getInetAddress());
			System.out.println("Host Port: " + conn.getPort());
			System.out.println("My IP    : " + conn.getLocalAddress());
			System.out.println("My Port  : " + conn.getLocalPort());
			
			// sockets have two streams, input and output ; we'll talk more about them as we go
			istream = conn.getInputStream();
			reader = new InputStreamReader(istream, "UTF-8");
			String time = "";
			for(int ch = reader.read(); ch != -1; ch = reader.read()) {
				time += ((char) ch);
			} 
			System.out.println("The time is: " + time);

			reader.close();
			conn.close();
			
		} catch (IOException e) {
			System.out.println("Server error: " + e);
		}
	}
	
}
