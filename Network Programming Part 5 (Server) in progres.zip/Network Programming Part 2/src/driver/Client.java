package driver;

import java.io.IOException;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {
		Socket conn = null;
		try {
			conn = new Socket("192.168.0.1", 4242);
			service(conn);
			conn.close();
		} catch (IOException e) {
			System.out.println("Server error: " + e);
		}
	}
	
	public static void service(Socket conn) {
		
	}

}
