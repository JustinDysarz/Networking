package driver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

public class DictionaryExample {

	public static void main(String[] args) {
		String wordToDefine = "thing";
		int TIMEOUT = 15000; // 15000 milliseconds
		String host = "dict.org";
		int port = 2628;
		Socket conn = null;
		InputStream istream = null;
		InputStreamReader irstream = null;
		BufferedReader reader = null;
		OutputStream outstream = null;
		Writer writer = null; 
		
		try {
			conn = new Socket(host, port);
			conn.setSoTimeout(TIMEOUT); 
			System.out.println("Host IP  : " + conn.getInetAddress());
			System.out.println("Host Port: " + conn.getPort());
			System.out.println("My IP    : " + conn.getLocalAddress());
			System.out.println("My Port  : " + conn.getLocalPort());	
			
			istream = conn.getInputStream();
			irstream = new InputStreamReader(istream, "UTF-8");
			reader = new BufferedReader(irstream);
			
			outstream = conn.getOutputStream();
			writer = new OutputStreamWriter(outstream, "UTF-8");
			
			writer.write("SHOW DB\r\n");
			writer.write("DEFINE gcide " + wordToDefine + "\r\n");
			writer.flush();
			
			String line = reader.readLine();
			while(line != null) {
				System.out.println(line);
				if(line.startsWith("250 ")) {
					writer.write("quit\r\n");
					writer.flush();
				}
				line = reader.readLine();
			}

			reader.close();
			writer.close();
			conn.close();	
			
		} catch (IOException e) {
			System.out.println("Server error: " + e);
		}
	}
	
}
