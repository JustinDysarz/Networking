package client;

public class ClientDriver {

	public static void main(String[] args) {
		Client client = new Client("localhost", 5995);
		//Client client = new Client("192.168.0.11", 5995);

		client.send("Hello computer.");
	}

}
