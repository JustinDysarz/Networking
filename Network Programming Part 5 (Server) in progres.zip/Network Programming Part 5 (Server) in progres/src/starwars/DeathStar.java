package starwars;

public class DeathStar {
	
	private int HP;
	
	public DeathStar(int HP) {
		this.HP = HP;
	}

	public void attacked(int amount) {
		this.HP -= amount;
		System.out.println("Death Star attacked");
	}
	
	public void repaired(int amount) {
		this.HP += amount;
		System.out.println("Death Star repaired");
	}
	
	public int getHealth() {
		return HP;
	}
}
