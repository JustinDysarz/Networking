package client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	
	private Socket client;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public Client(String ip, int port) {
		try {
			client = new Socket(ip, port);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void send(String message) {
        try {
        	System.out.println("Client Info: " + client.getLocalSocketAddress());
			oos = new ObjectOutputStream(client.getOutputStream());
			ois = new ObjectInputStream(client.getInputStream());
			
			oos.writeObject(message);
			String greeting = (String) this.ois.readObject();
			System.out.println("From server: " + greeting);
			
			client.close();	
						
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
}
