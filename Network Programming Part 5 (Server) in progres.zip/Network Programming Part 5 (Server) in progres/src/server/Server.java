package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	private ServerSocket server;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public Server(int port) {
		try {
			server = new ServerSocket(port);
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	public void receive() {
		try {
			System.out.println("Server Info: " + server.getLocalSocketAddress());
			while (true) {
				Socket client = server.accept();
				System.out.println("Client connected: " + client.getInetAddress());
				oos = new ObjectOutputStream(client.getOutputStream());	
				ois = new ObjectInputStream(client.getInputStream());

				// block wait for input
				String message = (String) this.ois.readObject();
				System.out.println("From client: " + message);
				// send a response
				String response = "Hello client";
				this.oos.writeObject(response);
				
				client.close();
			}
			// server.close();	// unreachable because of the infinite loop
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
